# 1121 Introduction to Robotics I/O Wiring Schematic

